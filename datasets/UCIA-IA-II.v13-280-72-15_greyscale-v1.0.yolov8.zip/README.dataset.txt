# UCIA-IA-II > 280-72-15_greyscale-v1.0
https://universe.roboflow.com/ucia/ucia-ia-ii

Provided by a Roboflow user
License: CC BY 4.0

