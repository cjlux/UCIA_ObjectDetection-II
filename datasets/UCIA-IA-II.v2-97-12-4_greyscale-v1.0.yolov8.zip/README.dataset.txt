# UCIA-IA-II > 97-12-4_greyScale-v1.0
https://universe.roboflow.com/ucia/ucia-ia-ii

Provided by a Roboflow user
License: CC BY 4.0

