# UCIA-IA-II > 248-84-0_greyscale-v1.0
https://universe.roboflow.com/ucia/ucia-ia-ii

Provided by a Roboflow user
License: CC BY 4.0

