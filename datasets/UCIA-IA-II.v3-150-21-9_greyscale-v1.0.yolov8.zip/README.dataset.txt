# UCIA-IA-II > 150-21-9_greyscale-v1.0
https://universe.roboflow.com/ucia/ucia-ia-ii

Provided by a Roboflow user
License: CC BY 4.0

