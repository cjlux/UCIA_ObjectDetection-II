# UCIA-IA-II > 166-24-13_greyscale-v1.1
https://universe.roboflow.com/ucia/ucia-ia-ii

Provided by a Roboflow user
License: CC BY 4.0

